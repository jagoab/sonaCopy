<script type="text/javascript">
    $(document).ready(function() {
    // add the fancy box click handler here
    setTimeout(function() {
        $("#yw0_button").trigger('click');
    },1);
});
</script>
<?php
    foreach(Yii::app()->user->getFlashes() as $key => $message) {
        echo '<div class="flash-' . $key . '">' . $message . "</div>\n";
    }
?>

<style>
    .errorMessage{
        font-weight: bold;
        color: #c82a2a;
    }
    </style>
<div class="row">
    
    <div style='text-align: left;' class="col-md-4 helvetica_condensed_lightRg">
        <?php  $form = $this->beginWidget('CActiveForm', array('id' => 'contact-form','enableClientValidation' => true,'clientOptions' => array('validateOnSubmit' => true))); ?> 
            <div style="text-align: left; color: #808080; ">
                  <h2><?php echo Yii::t('forms', 'Send'); ?></h2>
                  <?php echo Yii::t('forms', 'You can contact us through this simple form. We will gladly answer at the earliest opportunity:'); ?>
            </div>  
        <hr />
            <div>
                <?php echo $form->labelEx($model, Yii::t('forms', 'Name')); ?>
                <?php echo $form->textField($model, 'name', array("class" => 'form-control', 'placeholder' => Yii::t('forms', 'Name'))); ?>
                <?php echo $form->error($model, 'name'); ?>
            </div>
            <div>
                <?php echo $form->labelEx($model, Yii::t('forms', 'Email')); ?>
                <?php echo $form->textField($model, 'email', array("class" => 'form-control', 'placeholder' => Yii::t('forms', 'Email'))); ?>
                <?php echo $form->error($model, 'email'); ?>
            </div>
            <div>
                <?php echo $form->labelEx($model, Yii::t('forms', 'Phone')); ?>
                <?php echo $form->textField($model, 'phone', array("class" => 'form-control', 'placeholder' =>Yii::t('forms', 'Phone'))); ?>
                <?php echo $form->error($model, 'phone'); ?>
            </div>
            <div>
                <?php echo $form->labelEx($model, Yii::t('forms', 'City')); ?>
                <?php echo $form->textField($model, 'city', array("class" => 'form-control', 'placeholder' =>  Yii::t('forms', 'City'))); ?>
                <?php echo $form->error($model, 'city'); ?>
            </div>
            <div>
                <?php echo $form->labelEx($model, Yii::t('forms', 'Message')); ?>
                <?php echo $form->textArea($model, 'body', array('rows' => 6, 'cols' => 50, 'style' => 'resize:none;', "class" => 'form-control', 'placeholder' => Yii::t('forms', 'Message'))); ?>
                <?php echo $form->error($model, 'body'); ?>
            </div>
            <div>
                <?php if (CCaptcha::checkRequirements()): ?>
                    <div style='margin-left: 10px;' class="row">
                        <?php echo $form->labelEx($model,Yii::t('forms', 'Verification Code')); ?>
                        <div style="position: relative; left: 10px;">
                            <?php $this->widget('CCaptcha'); ?>
                        </div>
                        <?php echo $form->textField($model, 'verifyCode'); ?>
                        <?php echo $form->error($model, 'verifyCode'); ?>
                    </div>
                <?php endif; ?>
            </div>
             <div style='margin-left: 10px;' class="btn-group" >
                <?php echo CHtml::Button(Yii::t('forms', 'Go back'), array('class' => 'btn btn-primary', 'onclick' => 'history.back(-1)')); ?>    
                <?php echo CHtml::submitButton(Yii::t('forms', 'Submit'), array('class' => 'btn btn-primary')); ?>
            </div>

         <?php $this->endWidget(); ?>
    </div><!---fin-de col md 4---->
 
    <div class="col-md-8 helvetica_neueregular">           
          <?php  foreach ($contactos_list as $contacto2):
              
             if(Yii::app()->session['flag'] == $contacto2['language'] ||
                     ((Yii::app()->session['flag']=='co'|| Yii::app()->session['flag']=='ve' || Yii::app()->session['flag']=='pe'
                      || Yii::app()->session['flag']=='pa'|| Yii::app()->session['flag']=='cl') &&  $contacto2['language']=='us')  ){?>
                                      
             <div class="panel panel-sonaray"> 
                 <div class="panel-heading"><?php echo $contacto2['name']; ?> </div>
                <div class="panel-body">                   
                    <div style="color: #000;"><?php echo $contacto2['text']; ?></div>
                                        
               </div>
              </div>      
            
                 
             <?php  } endforeach; ?>        
    </div>
     <div class="col-md-8 helvetica_neueregular">           
          <?php  foreach ($contactos_list as $contacto2):
              
             if(Yii::app()->session['flag'] != $contacto2['language'] ){
              
              ?>  
             <div class="panel panel-default">              
                <div class="panel-body">
                    <div style="font-weight: bold;"><?php echo $contacto2['name']; ?> </div>
                    <?php echo $contacto2['text']; ?>
               </div>
              </div>
            <?php } endforeach; ?>        
    </div>
    
</div>


<script type="text/javascript">

/* <![CDATA[ */

var google_conversion_id = 989228242;

var google_conversion_language = "en";

var google_conversion_format = "2";

var google_conversion_color = "ffffff";

var google_conversion_label = "XJzICKbk1AcQ0tnZ1wM";

var google_conversion_value = 0;

var google_remarketing_only = false;

/* ]]> */

</script>

<script type="text/javascript" src="www.googleadservices.com/pagead/conversion.js"></script>

<noscript>
	


<div style="display:inline;">

<img height="1" width="1" style="border-style:none;" alt="" src="www.googleadservices.com/pagead/conversion/989228242/?value=0&amp;label=XJzICKbk1AcQ0tnZ1wM&amp;guid=ON&amp;script=0"/>

</div>

</noscript>

