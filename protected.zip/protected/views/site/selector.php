<div class="panel panel-default">
  <div class="panel-heading"><?php echo Yii::t('forms','Asia Pacific'); ?></div>
  <div class="panel-body">
      <div class="flag">
          <a class="widthFlag" title="ES-AU" href="<?php echo Yii::app()->request->baseUrl."/ch/site/flagUrl?flag=au&lang=en"  ?>"><img width="32px;" src="<?php echo Yii::app()->request->baseURL; ?>/images/flag/au.png"/>  <?php echo Yii::t('forms','Australia') ?></a>
          <a class="widthFlag" title="ES-CH" href="<?php echo Yii::app()->request->baseUrl."/ch/site/flagUrl?flag=cn&lang=ch"  ?>"><img width="32px;" src="<?php echo Yii::app()->request->baseURL; ?>/images/flag/cn.png"/>  <?php echo Yii::t('forms','中国') ?></a>
          <a class="widthFlag" title="ES-HK" href="<?php echo Yii::app()->request->baseUrl."/ch/site/flagUrl?flag=hk&lang=ch"  ?>"><img width="32px;" src="<?php echo Yii::app()->request->baseURL; ?>/images/flag/hk.png"/>  <?php echo Yii::t('forms','Hong Kong') ?></a>
          <a class="widthFlag" title="ES-SI" href="<?php echo Yii::app()->request->baseUrl."/ch/site/flagUrl?flag=sg&lang=ch"  ?>"><img width="32px;" src="<?php echo Yii::app()->request->baseURL; ?>/images/flag/sg.png"/>  <?php echo Yii::t('forms','Singapore') ?></a>
      </div>
    
  </div>
</div>

<div class="panel panel-default">
  <div class="panel-heading"><?php echo Yii::t('forms','Europe'); ?></div>
  <div class="panel-body">
      <div class="flag">
         <a  title="ES-DE" href="<?php echo Yii::app()->request->baseUrl."/en/site/flagUrl?flag=de&lang=en"  ?>"><img width="32px;" src="<?php echo Yii::app()->request->baseURL; ?>/images/flag/de.png"/>  <?php echo Yii::t('forms','Deutschland'); ?>  </a>
      </div>
    
  </div>
</div>

<div class="panel panel-default">
  <div class="panel-heading"><?php echo Yii::t('forms','Latin America and the Caribbean'); ?></div>
  <div class="panel-body">
      <div class="flag">
          <a class="widthFlag" title="ES-VE" href="<?php echo Yii::app()->request->baseUrl."/es/site/flagUrl?flag=ve&lang=es"  ?>"><img width="32px;" src="<?php echo Yii::app()->request->baseURL; ?>/images/flag/ve.png"/>  <?php echo Yii::t('forms','Venezuela'); ?></a>
          <a class="widthFlag" title="ES-CO" href="<?php echo Yii::app()->request->baseUrl."/es/site/flagUrl?flag=co&lang=es"  ?>"><img width="32px;" src="<?php echo Yii::app()->request->baseURL; ?>/images/flag/co.png"/>  <?php echo Yii::t('forms','Colombia'); ?></a>
          <a class="widthFlag" title="ES-BR" href="<?php echo Yii::app()->request->baseUrl."/po/site/flagUrl?flag=br&lang=po"  ?>"><img width="32px;" src="<?php echo Yii::app()->request->baseURL; ?>/images/flag/br.png"/>  <?php echo Yii::t('forms','Brasil'); ?></a>
          <a class="widthFlag" title="ES-MX" href="<?php echo Yii::app()->request->baseUrl."/es/site/flagUrl?flag=mx&lang=es"  ?>"><img width="32px;" src="<?php echo Yii::app()->request->baseURL; ?>/images/flag/mx.png"/>  <?php echo Yii::t('forms','Mexico'); ?></a>
          <a class="widthFlag" title="ES-PE" href="<?php echo Yii::app()->request->baseUrl."/es/site/flagUrl?flag=pe&lang=es"  ?>"><img width="32px;" src="<?php echo Yii::app()->request->baseURL; ?>/images/flag/pe.png"/>  <?php echo Yii::t('forms','Peru'); ?></a>
          <a class="widthFlag" title="ES-PA" href="<?php echo Yii::app()->request->baseUrl."/es/site/flagUrl?flag=pa&lang=es"  ?>"><img width="32px;" src="<?php echo Yii::app()->request->baseURL; ?>/images/flag/pa.png"/>  <?php echo Yii::t('forms','Panama'); ?></a>
          <a class="widthFlag" title="ES-CL" href="<?php echo Yii::app()->request->baseUrl."/es/site/flagUrl?flag=cl&lang=es"  ?>"><img width="32px;" src="<?php echo Yii::app()->request->baseURL; ?>/images/flag/cl.png"/>  <?php echo Yii::t('forms','Chile'); ?></a>
      </div>
    
  </div>
</div>

<div class="panel panel-default">
  <div class="panel-heading"><?php echo Yii::t('forms','The United States'); ?></div>
  <div class="panel-body">
      <div class="flag">
          <a  title="EN-US" href="<?php echo Yii::app()->request->baseUrl."/en/site/flagUrl?flag=us&lang=en"  ?>"><img width="32px;" src="<?php echo Yii::app()->request->baseURL; ?>/images/flag/us.png"/>  <?php echo Yii::t('forms','United States'); ?></a>         
      </div>
    
  </div>
</div>