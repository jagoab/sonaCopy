<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/jquery.accordion.css" />
<script type="text/javascript" src="<?php echo Yii::app()->request->baseUrl; ?>/js/jquery.accordion.js"></script>

<style>
	.accordion-ver ul li {
			background-color: #9c9aa0
			}
			.accordion-ver ul li div {
                           background-color: #ffffff
			}
			.accordion-ver ul li h1 {
				color: #ffffff
			}
			.accordion-ver ul li div span {
				color: #242424
			}
			.accordion-ver ul li i {
				color: #a3a3a3
			}
			.accordion-ver ul li i {
				font-size: 15px
			}
			.accordion-ver ul li h1 {
				font-size: 13px
			}

			.accordion-ver ul li {
				border-width: 3px
			}

			.accordion-ver ul li div span {
				padding: 10px
			}
			
			.detalleProduct{
			   width: 13%; 
			   height: auto; 
			}
			
			.accordion-hor > ul > li > h1{
			
				top:38% !important;
			
			}
			
			.alturaMenu a{
			    font-size: 16px !important;
			}
</style>

<script type="text/javascript">

activarCarosel = function() {
	$('span').css('width','');
	$('.imagen0').css('width','30%');	
	$('.texto0').css('width','65%');
	$('.texto0').css('text-align: justify');
        
	$('.imagen1').css('width','30%');
        $('.imagen1').css('margin-left','3%');	
	$('.imagen1').css('padding-top','4%');	        
	$('.texto1').css('width','64%');
	$('.texto1').css('text-align: justify');
        
	$('.imagen2').css('width','40%');	
	$('.imagen2').css('margin-left','2%');	
	$('.imagen2').css('padding-top','5%');	
	$('.texto2').css('width','54%');	
	$('.texto2').css('text-align: justify');	
        
	$('.imagen3').css('width','30%');	
	$('.imagen3').css('margin-left','3%');	
	$('.texto3').css('width','65%');	
	$('.texto3').css('text-align: justify');	
};

</script>
<div id="accordion1">
    <ul>
    <?php $i = 0;?>
    <?php foreach ($parrafos as $valor):?>
    <li onclick="activarCarosel()">
        <h1><?php  echo $valor[0]->text; ?></h1>
        <div style="width: 100%;height: auto">
            <span>
                <div class="textoInterno" style="margin-left:0%;  position: relative; font-size: 8pt;">
                    <h2 style="font-family: Helvetica-Condensed-Light;"><?php echo $valor[1]->text; ?></h2>
                </div>
            </span>
            <span class="imagen<?php echo $i;?>" style="width: 30%;clear:both;float:left;">
                <img src="<?php echo Yii::app()->request->baseUrl.$imagenesAboutUs[$i]->path; ?>" style="width: 100%;" />
            </span>
            <span class="texto<?php echo $i;?>" style="float:left; width: 65%; text-align: justify; margin-left: 14px; margin-top: 5%;font-size: 10pt">
                <?php echo $valor[2]->text; ?>
            </span>
        </div>
    </li>

    <?php $i++;?>
    <?php endforeach;?>

    </ul>
</div>

<script>
$("#accordion1").awsAccordion({
     type:"horizontal",
    cssAttrsVer:{
        ulWidth:"responsive",
        liHeight:45
    },
    cssAttrsHor:{
        ulWidth:"responsive",
        liWidth:45,
        liHeight:390,
        responsiveMedia:"(max-width: 800px)"
    },
    
    startSlide:1,
    
    openOnebyOne:true,
    classTab:"active",
    slideOn:"click"
})
</script>