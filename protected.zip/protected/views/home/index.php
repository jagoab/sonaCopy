<!--------------------------------CAROUSEL------------------------------------------------------>
            <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">              
                <ol class="carousel-indicators">
                    <?php
                        $i = 0;
                        foreach($imagenesSlider as $banner):
                            $cantidad = count($banner);
                            for($j = 0; $j<$cantidad; $j++){                       
                        ?>
                            <li data-target="#carousel-example-generic" data-slide-to="<?php echo $j; ?>" <?php if($j==0){ echo ' class="active"';} ?>></li>
                        <?php 
                        } 
                        endforeach;
                        ?>
                </ol>
               <div class="carousel-inner">
                    <?php 
                            foreach($imagenesSlider as $banner){
                                if($i == 0){ $i++;
                        ?>
                    <div class="item active">
				<a href="<?php echo $banner->link; ?>">	
                        <?php echo CHtml::image(Yii::app()->request->baseUrl.$banner->ruta,"",array('width'=>'100%')); ?>
				</a>
                    </div>
                    <?php } else { ?>
                    <div class="item">
                        <a href="<?php echo $banner->link; ?>">	
                        <?php echo CHtml::image(Yii::app()->request->baseUrl.$banner->ruta,"",array('width'=>'100%')); ?>
                    </a>
                    </div>
                   <?php }  } ?>
             
                </div>
                <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left"></span>
               </a>
               <a  class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right"></span>
               </a>
            </div><!--fin del carousel--->
         
<!-------------------------------------------------------------------------------------------------------------------------->
<br />
<div class="row">   
    <div class="col-md-4 col-sm-4 col-lg-4"> 
        <?php foreach ($casos as $caso): ?>       
            <?php echo CHtml::link($caso['text'], array($caso['path'])); ?>
        <?php endforeach; ?>
        <?php foreach ($imagenesCasos as $imagenesCaso): ?>
            <a href="<?php echo Yii::app()->request->baseUrl . "/" . $imagenesCaso['subPath'] ?>"><?php echo CHtml::image(Yii::app()->request->baseUrl . $imagenesCaso['path'], "", array('width' => '100%')); ?></a>
        <?php endforeach; ?>
    </div>
    
    <div class="col-md-4 col-sm-4 col-lg-4"> 
        <?php foreach ($descargas as $descarga): ?>       
            <?php echo CHtml::link($descarga['text'], array($descarga['path'])); ?>
        <?php endforeach; ?>
        <?php foreach ($imagenesDescargas as $imagenesDescarga): ?>
            <a href="<?php echo Yii::app()->request->baseUrl . "/" . $imagenesDescarga['subPath'] ?>"><?php echo CHtml::image(Yii::app()->request->baseUrl . $imagenesDescarga['path'], "", array('width' => '100%')); ?></a>
        <?php endforeach; ?>
    </div>
    
    <div class="col-md-4 col-sm-4 col-lg-4"> 
        <?php foreach ($destacados as $destacado): ?>       
            <?php echo CHtml::link($destacado['text'], array($destacado['path'])); ?>
        <?php endforeach; ?>
        <?php foreach ($featured_product as $imagenesCasosDescarga): ?>
              <a href="<?php echo Yii::app()->baseUrl."/products/index?idclick=".$imagenesCasosDescarga['id'] ?>"><?php echo CHtml::image(Yii::app()->request->baseUrl.$imagenesCasosDescarga['path'],"",array('width'=>'80%','class'=>'img-thumbnail')); ?></a>
        <?php endforeach; ?>
    </div>


</div>
