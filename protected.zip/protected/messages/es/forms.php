<?php
	return array(
				'Name' => 'Nombre',
				'Email' => 'Correo',
				'Subject' => 'Asunto',
				'Message' => 'Mensaje',	
				'Go back' =>'Regresar',
                'Submit' =>'Enviar',
                'language'=>'Idioma',
                'Send'=>'Enviar',
                'Phone'=>'Teléfono',
                'City'=>'Ciudad',
                'language'=>'Lenguaje',
                'All'=>'Todos',
                'Files Type'=>'Tipo de Archivo',
                'Product Type'=>'Tipo de Producto',
                'Product'=>'Producto',               
                'Model'=>'Modelo',
                'Select'=>'Seleccione',
                'Change Country'=>'Cambiar País',
                'Verification Code'=>'Verificar Código',
                'Asia Pacific'=>'Asia y el Pacífico',
                'Europe'=>'Europa',
                'Latin America and the Caribbean'=>'Latino América y el Caribe',
                'The United States'=>'Estados Unidos',
                'You can contact us through this simple form. We will gladly answer at the earliest opportunity:'=>'Puede contactar con nosotros a través de este sencillo formulario. Le responderemos con mucho gusto en la primera oportunidad'
);
?>
