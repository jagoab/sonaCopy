<?php
	return array(
				'Nombre' => 'Name',
				'Correo' => 'Email',
				'Asunto' => 'Subject',
				'Telefono' => 'Phone',		
				'Commentarios' => 'Body',
				'Phone Number' => 'Número telefonico',		
                'Regresar' =>'Go Back',
                'Enviar' =>'Submit',
                'Idioma'=>'language',
                'Enviar'=>'Send',
                'Todos'=>'All',
                'Chambiar Pais'=>'Change Country',
                'Puede contactar con nosotros a través de este sencillo formulario. Le responderemos con mucho gusto en la primera oportunidad'=>'You can contact us through this simple form. We will gladly answer at the earliest opportunity:'
);
